

class TelaSistema:
  def __init__(self):
    pass

  def mostrar_menu_inicial(self):
    print("=======MENU INICIAL========")
    print("1- Realizar login")
    print("2- Cadastrar")
    opcao=int(input("Opção: "))
    return opcao