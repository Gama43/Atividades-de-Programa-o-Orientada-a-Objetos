class TelaUsuario:
  def __init__(self):
    pass

  def mostra_tela_login(self):
    print("+++++++++LoginXDXDXDXDXDXD")
    nome = input("Nome: ")
    senha = input("Senha: ")

    return {"nome": nome, "senha": senha}

  def mostra_mensagem(self, mensagem):
    print(mensagem)

  def mostra_tel_opcoes(self):
    print("===Cadastro usuarios===")
    print("1-incluir usuario")
    print("2-alterar usuario")
    print("3-excluir usuario")
    print("4-listar usuario")
    print("0-retornar")