from controladores.ctrl_usuario import CtrlUsuario
from tela.tela_sistema import TelaSistema

class CtrlSistema:
  def __init__(self):
    self.__tela_sistema = TelaSistema()
    self.__tela_sistema=TelaSistema()

  def iniciar(self):
    while True:
      opcao_escolhida=self.__tela_sistema.mostrar_menu_incial()
        
      if opcao_escolhida == 1:
        if (self.__ctrl_usuario.logar()):
           self.__ctrl_usuario.abre_tela_inicial()
      
      elif opcao_escolhida==2:
        pass
      
      else:
        break
    
if __name__ == "__main__":
  ctrl_sistema = CtrlSistema()
  ctrl_sistema.iniciar()