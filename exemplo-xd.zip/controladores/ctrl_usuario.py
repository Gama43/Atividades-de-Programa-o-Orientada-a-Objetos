from tela.tela_usuario import TelaUsuario
from entidade.usuario import Usuario
class CtrlUsuario:
  def __init__(self):
    self.__usuarios = []
    self.__tela_usuario = None

  
  def logar(self):
    # pega dados do usuario
    dados_usuario= self.__tela_usuario.mostra_tel_login()

    self.__tela_usuario.mostra_tela_login()
    # procura por nome e senha 
    for usuario in self.__usuarios:
      if (usuario.nome == dados_usuario['nome']) and \
        (usuario.senha == dados_usuario['senha']):
          self.__tela_usuario.mostra_mensagem('Logado com sucesso')
          return usuario

    else:
      self.__tela_usuario.mostra_mensagem('Burro digitou errado')
      return None

  def incluir(self):
    pass


  def alterar(self):
    pass


  def excluir(self):
    pass


  def listar(self):
    pass

  def abre_tela_inicial(self):
    switcher={0:self.retornar,1:self.incluir, 2:self.alterar, 3: self.excluir, 4: self.listar}
    while True:
      opcao_escolhida = self.__tela_usuario.mostra_tela_opcoes()
      switcher[opcao_escolhida]()


