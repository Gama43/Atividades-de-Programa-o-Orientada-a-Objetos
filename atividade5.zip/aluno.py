from usuario_bu import UsuarioBU

class Aluno(UsuarioBU):
  def __init__(self, matricula:int, cpf, dias_de_emprestimo):
    super().__init__(cpf, dias_de_emprestimo)
    if isinstance (matricula, int):
      self.__matricula = matricula

  @property
  def matricula(self):
    return self.__matricula
  
  @matricula.setter
  def matricula(self, matricula: int):
    if isinstance(matricula, int):
      self.__matricula = matricula