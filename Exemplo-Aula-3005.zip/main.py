from controladores.ctrl_sistema import CtrlSistema

if __name__ == "__main__":
  ctrl_sistema = CtrlSistema()
  ctrl_sistema.iniciar()